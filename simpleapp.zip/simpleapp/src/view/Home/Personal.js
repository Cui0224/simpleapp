import React, { Component } from 'react'

export default class Personal extends Component {
    render() {
        return (
            <div>
                personal
            </div>
        )
    }
}
