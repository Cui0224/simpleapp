import React, { Component } from 'react'

export default class Lol extends Component {
    render() {
        return (
            <div>
                lol
            </div>
        )
    }
}
