import React, { Component } from 'react'

export default class Theater extends Component {
    render() {
        return (
            <div>
                theater
            </div>
        )
    }
}
