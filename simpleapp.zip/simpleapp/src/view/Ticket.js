import React, { Component } from 'react'

export default class Ticket extends Component {
    render() {
        return (
            <div>
                ticket
            </div>
        )
    }
}
