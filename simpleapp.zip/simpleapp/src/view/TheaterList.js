import React, { Component } from 'react'

export default class TheaterList extends Component {
    render() {
        return (
            <div>
                TheaterList
            </div>
        )
    }
}
