import React, { Component } from 'react'

export default class Query extends Component {
    render() {
        return (
            <div>
                Query
            </div>
        )
    }
}
