import React, { Component } from 'react'

export default class Pay extends Component {
    render() {
        return (
            <div>
                pay
            </div>
        )
    }
}
