/* 
    redux文件夹
    到时候再说哪些数据放redux，哪些不用放

    reducers: 写redux 方法文件 

    action_types: 写action.type的文件，定义各种对应type的文件

    action_creators : 写 action 调用方法的文件夹，尽可能单独创建文件夹，或者备注详细点写一起我感觉没啥问题
*/
